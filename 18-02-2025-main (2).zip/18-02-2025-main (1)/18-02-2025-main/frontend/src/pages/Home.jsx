import React from 'react'

const Home = () => {
  return (
    <div>
     <img src="\sandwitch.jpg" class="img-fluid w-100 pt-1" alt="..."/ >
     <div class="row row-cols-1 row-cols-md-2 g-4 m-2">
  <div class="col">
    <div class="card">
      <img src="/puranPoli.jpg" height="300px" width="200px" class="card-img-top" alt="..."/>
      <div class="card-body">
        <h5 class="card-title">Puran Poli</h5>
        <p class="card-text">Puran poli is an Indian sweet flatbread that is popular in South India and the state of Maharashtra. It is also known as puran puri.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="/DalBhat.jpg" height="300px" width="200px" class="card-img-top" alt="..."/ >
      <div class="card-body">
        <h5 class="card-title">Dal Bhat (Varan Bhat)</h5>
        <p class="card-text">Dal bhat · Nepali khana—dal bhat tarkari · Nepalese-style dal bhat · Traditional dal bhat thali .</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="/misal.jpg" height="300px" width="200px" class="card-img-top" alt="..."/ >
      <div class="card-body">
        <h5 class="card-title">Misal Pav</h5>
        <p class="card-text">Misal is a very popular spicy dish in the Western Indian state of Maharashtra..</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="/mutton.jpg" height="300px" width="200px" class="card-img-top" alt="..." />
      <div class="card-body">
        <h5 class="card-title">Mutton thali</h5>
        <p class="card-text">Mutton is meat from a mature sheep. It's a red meat that's high in protein and nutrients..</p>
      </div>
    </div>
  </div>
</div>
    </div>
  )
}

export default Home
